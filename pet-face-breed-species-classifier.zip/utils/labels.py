# Oxford-IIIT Pet Dataset has 37 categories.
# The exact order used by the training dataset is saved to models/class_names.json.
CAT_BREEDS = {
    "Abyssinian", "Bengal", "Birman", "Bombay", "British Shorthair",
    "Egyptian Mau", "Maine Coon", "Persian", "Ragdoll", "Russian Blue",
    "Siamese", "Sphynx"
}

DOG_BREEDS = {
    "American Bulldog", "American Pit Bull Terrier", "Basset Hound",
    "Beagle", "Boxer", "Chihuahua", "English Cocker Spaniel",
    "English Setter", "German Shorthaired", "Great Pyrenees",
    "Havanese", "Japanese Chin", "Keeshond", "Leonberger",
    "Miniature Pinscher", "Newfoundland", "Pomeranian", "Pug",
    "Saint Bernard", "Samoyed", "Scottish Terrier", "Shiba Inu",
    "Staffordshire Bull Terrier", "Wheaten Terrier", "Yorkshire Terrier"
}

def species_from_breed(breed: str) -> str:
    if breed in CAT_BREEDS:
        return "Cat"
    if breed in DOG_BREEDS:
        return "Dog"
    return "Unknown"
